namespace boost { namespace logging {

/** 
@page customize_manipulator Customizing manipulator arguments (Advanced)

FIXME

optimize::cache_string_on_str
optimize::cache_string_several_str


@section customize_optimize Optimizing manipulator arguments

optimize::cache_string_on_str
optimize::cache_string_several_str


FIXME

*/

}}
